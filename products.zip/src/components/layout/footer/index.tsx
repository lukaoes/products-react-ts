import { FooterLayout } from "./footer.styled";

const Footer = () => {

    return (
        <FooterLayout>
            Created By  <span> Luka Pitskhelauri</span>
        </FooterLayout>
    )
}

export default Footer;