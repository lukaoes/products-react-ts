import styled from "styled-components";

export const AboutDiv = styled.div`
    max-width: 900px;
    margin: 0 auto;
    padding: 10px;
`